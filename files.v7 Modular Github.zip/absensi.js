// ═══════════════════════════════════════════════════════════════
//  absensi.js — Rekap Absensi PIC: load, render, export Excel
// ═══════════════════════════════════════════════════════════════

async function loadAbsensi(){
  var bulan = document.getElementById('absen-filter-bulan')?.value || '';
  var tahun = document.getElementById('absen-filter-tahun')?.value || String(new Date().getFullYear());
  // Non-manager hanya bisa lihat data sendiri
  var pic = currentRole==='manager'
    ? (document.getElementById('absen-filter-pic')?.value||'')
    : ((currentUser&&currentUser.name)||'');
  var el    = document.getElementById('absensi-content');
  if(!el) return;
  el.innerHTML = '<div class="loading-text">⏳ Menyusun data absensi...</div>';
  try {
    var json = await fetchGAS({action:'generateAbsensi', bulan, tahun, pic, pin: currentPin});
    if(json.status !== 'ok' || !json.data || !json.data.length){
      el.innerHTML = '<div class="no-data"><div class="no-data-icon">📋</div>Tidak ada data untuk periode ini.</div>';
      return;
    }
    _absensiData = json.data;
    renderAbsensiPreview(_absensiData);
  } catch(e) {
    el.innerHTML = '<div class="no-data">Gagal koneksi.</div>';
  }
}

function renderAbsensiPreview(dataArr){
  var el = document.getElementById('absensi-content');
  if(!el) return;

  // Build tab buttons
  var tabsHtml = '';
  for(var ti=0; ti<dataArr.length; ti++){
    var activeClass = ti===0 ? 'sub-btn active' : 'sub-btn';
    tabsHtml += '<button class="'+activeClass+'" onclick="showAbsensiTab('+ti+')" id="absen-tab-'+ti+'">'+dataArr[ti].pic+'</button> ';
  }

  // Build panels
  var panelsHtml = '';
  for(var pi=0; pi<dataArr.length; pi++){
    var picData = dataArr[pi];
    var rowsHtml = '';
    for(var ri=0; ri<picData.rows.length; ri++){
      var r = picData.rows[ri];
      var isLibur = r.kegiatan === 'Libur';
      var isTL    = r.status === 'TL';
      var bg = '#fff';
      if(r.hari === 'Sabtu') bg = '#e0f2fe';
      else if(r.hari === 'Minggu') bg = '#fee2e2';
      else if(isTL) bg = '#f3e5f5';
      var kegHuman = _formatKegiatanHuman(r.kegiatan);
      var tglFmt = r.tgl ? new Date(r.tgl).toLocaleDateString('id-ID',{day:'numeric',month:'short'}) : '';
      var tlBadge = isTL ? '<span class="badge badge-purple">TL</span>' : '';
      var ketCell = isLibur ? '<span style="color:var(--text3);font-style:italic;">Libur</span>' : kegHuman;
      rowsHtml += '<tr style="background:'+bg+';border-bottom:1px solid var(--border);">';
      rowsHtml += '<td style="padding:6px 8px;font-size:12px;color:var(--text2);">'+r.hari+'</td>';
      rowsHtml += '<td style="padding:6px 8px;font-size:12px;color:var(--text2);">'+tglFmt+'</td>';
      rowsHtml += '<td style="padding:6px 8px;font-size:12px;">'+ketCell+'</td>';
      rowsHtml += '<td style="padding:6px 8px;font-size:12px;text-align:center;">'+(r.lokasi||'')+'</td>';
      rowsHtml += '<td style="padding:6px 8px;font-size:12px;text-align:center;">'+tlBadge+'</td>';
      rowsHtml += '</tr>';
    }
    var panelStyle = pi===0 ? '' : 'display:none;';
    panelsHtml += '<div id="absen-panel-'+pi+'" style="'+panelStyle+'">';
    panelsHtml += '<div style="font-size:12px;color:var(--text2);margin-bottom:8px;"><b>'+picData.pic+'</b> — '+picData.bulan+' '+picData.tahun+' · TL: '+picData.tlCount+' hari</div>';
    panelsHtml += '<div style="overflow-x:auto;"><table style="width:100%;border-collapse:collapse;font-size:12px;">';
    panelsHtml += '<thead><tr style="background:var(--surface3);"><th style="padding:7px 8px;text-align:left;">Hari</th><th style="padding:7px 8px;text-align:left;">Tgl</th><th style="padding:7px 8px;text-align:left;">Kegiatan</th><th style="padding:7px 8px;text-align:center;">Lokasi PIC</th><th style="padding:7px 8px;text-align:center;">Status</th></tr></thead>';
    panelsHtml += '<tbody>'+rowsHtml+'</tbody></table></div></div>';
  }

  el.innerHTML = '<div class="card" style="padding:12px;"><div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:12px;">'+tabsHtml+'</div>'+panelsHtml+'</div>';
}

function showAbsensiTab(idx){
  document.querySelectorAll('[id^="absen-tab-"]').forEach(function(b){b.classList.remove('active');});
  document.querySelectorAll('[id^="absen-panel-"]').forEach(function(p){p.style.display='none';});
  var tab = document.getElementById('absen-tab-'+idx);
  var panel = document.getElementById('absen-panel-'+idx);
  if(tab) tab.classList.add('active');
  if(panel) panel.style.display='block';
}

function _formatKegiatanHuman(raw){
  if(!raw) return '';
  return raw
    .replace(/\[HW\]\s*/g,'')
    .replace(/\[NET\]\s*/g,'')
    .replace(/OTS ke\s+/gi,'Kunjungan OTS ke ')
    .replace(/\u2192/g,'-')
    .replace(/;\s*/g,', ')
    .replace(/\s+/g,' ')
    .trim();
}

async function exportAbsensiServer(){
  const bulan = document.getElementById('absen-filter-bulan')?.value || new Date().toLocaleString('id',{month:'long'});
  const tahun = document.getElementById('absen-filter-tahun')?.value || String(new Date().getFullYear());
  const pic   = currentRole==='manager'
    ? (document.getElementById('absen-filter-pic')?.value||'')
    : ((currentUser&&currentUser.name)||'');

  showOverlay('Menyiapkan Excel Absensi...');
  try {
    // POST ke GAS — GAS build xlsx server-side, return base64
    const fd = new FormData();
    fd.append('data', JSON.stringify({
      action:'exportAbsensiExcel', pin:currentPin,
      bulan, tahun, pic
    }));
    const res  = await fetch(getUrl(), {method:'POST', body:fd});
    const json = await res.json();
    hideOverlay();

    if(json.status!=='ok' || !json.base64){
      showToast((json.message)||'Tidak ada data absensi','info'); return;
    }

    // Decode base64 → Blob → download lokal
    const byteChars = atob(json.base64);
    const byteArr   = new Uint8Array(byteChars.length);
    for(let i=0;i<byteChars.length;i++) byteArr[i]=byteChars.charCodeAt(i);
    const blob = new Blob([byteArr],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href=url; a.download=json.filename||('Absensi_'+bulan+'_'+tahun+'.xlsx');
    document.body.appendChild(a); a.click();
    setTimeout(()=>{ document.body.removeChild(a); URL.revokeObjectURL(url); },1000);
    showToast('File '+a.download+' diunduh!','ok');
  } catch(e){
    hideOverlay();
    showToast('Gagal: '+e.message,'err');
  }
}